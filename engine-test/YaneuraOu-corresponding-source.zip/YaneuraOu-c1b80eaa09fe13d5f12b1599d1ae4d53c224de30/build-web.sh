#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")/source"
variant="${1:?specify mini or micro}"
case "$variant" in
  mini) width=4096; factory=YaneuraOu_TsuyouMini ;;
  micro) width=2048; factory=YaneuraOu_TsuyouMicro ;;
  *) echo "Specify mini or micro" >&2; exit 2 ;;
esac
make clean
make tournament COMPILER=em++ TARGET_CPU=WASM \
  YANEURAOU_EDITION="YANEURAOU_ENGINE_SFNN_ka2_${width}_8_64_progress8" \
  EVAL_EMBEDDING=OFF EM_EXPORT_NAME="$factory" TARGET=yaneuraou.js
